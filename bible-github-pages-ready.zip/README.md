# 📖 Bible App — GitHub Pages Ready

A static Bible reading app built with HTML, CSS and JavaScript.

## What works

- Search Bible verses/references
- Keyword search through the connected Bible API
- Random verse
- Daily verse
- Old/New Testament book browsing
- Chapter 1 reading from a selected book
- Favorites
- Recently viewed
- Copy and native Share
- Private verse notes
- Personal prayers
- Feedback form
- Problem report form
- Demo feedback management area
- Light/dark/automatic theme
- Adjustable reading text size
- Browser-local saved data

## 1. Create the GitHub repository

1. Sign in to GitHub.
2. Click **New repository**.
3. Give it a name such as `bible-app`.
4. Choose Public if you are using GitHub Pages on a free GitHub account.
5. Create the repository.

## 2. Upload these files

Upload the contents of this ZIP so your repository has this structure:

```text
bible-app/
├── index.html
├── README.md
└── assets/
    ├── app.js
    └── style.css
```

Do not put the files inside an extra nested folder.

## 3. Turn on GitHub Pages

In your repository:

**Settings → Pages**

Under **Build and deployment**:

- Source: **Deploy from a branch**
- Branch: **main**
- Folder: **/ (root)**

Press **Save**.

GitHub will give you a Pages address. It normally looks like:

`https://YOUR-USERNAME.github.io/bible-app/`

It can take a few minutes for the first deployment.

## 4. Important: Bible API

The app currently calls:

`https://bible-api.com/`

The app therefore needs an internet connection for verse searches and daily/random verses.

If the API is unavailable, the app displays an error instead of crashing.

## 5. Important: feedback/admin security

GitHub Pages is a static hosting service. It cannot safely keep a secret administrator password or private shared feedback database in frontend JavaScript.

The `4817` code in this prototype is **only a demo gate**. Anyone who can inspect the site's JavaScript can discover it.

For a real production app, replace the demo feedback system with a backend such as:

- Supabase
- Firebase
- Appwrite
- Your own server/API

The backend should handle authentication, authorization, feedback storage, deletion and admin actions.

## 6. Translation licensing

This project uses the King James Version (KJV), which is public domain in the United States.

Before adding another translation, check that translation's licensing requirements and API terms. Do not copy a copyrighted Bible translation into the repository without permission.

## 7. Local data

Favorites, notes, history, prayers and demo feedback use `localStorage`.

That means:

- Data stays in the user's browser.
- Data does not automatically sync between devices.
- Clearing browser/site data can remove it.
- It is not a substitute for secure cloud storage.

## 8. Making it a real multi-user app

A production architecture could be:

```text
GitHub Pages
     │
     ├── Bible UI
     ├── Search
     ├── Favorites
     └── Settings
          │
          ▼
     Supabase / Firebase
          │
          ├── User accounts
          ├── Favorites
          ├── Notes
          ├── Prayers
          └── Feedback
                  │
                  ▼
             Admin dashboard
```

For the admin area, use server-side authentication and database rules. Do not put an administrator password directly in `app.js`.

## License

The application code in this repository is provided as a starter project. Check the licenses/terms of any third-party API, library, icon, font, image, or Bible translation you add.
